# Cappivate AI

This is an AI-powered content generation and auto-posting tool for social media.

## Features
- AI-powered content creation
- Auto-posting to social media
- Video generation
- Dropbox integration

## Installation
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the backend: `python backend/app.py`
