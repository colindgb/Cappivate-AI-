def suggest_live_responses(comment):
    return f"Great question! {comment} is something we love discussing."
